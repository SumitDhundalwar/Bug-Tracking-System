import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-elogout',
  templateUrl: './elogout.component.html',
  styleUrls: ['./elogout.component.css']
})
export class ElogoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
