import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-home',
  templateUrl: './emp-home.component.html',
  styleUrls: ['./emp-home.component.css']
})
export class EmpHomeComponent implements OnInit {

  title = 'bugtracking';
  constructor() { }

  ngOnInit(): void {
  }

}
