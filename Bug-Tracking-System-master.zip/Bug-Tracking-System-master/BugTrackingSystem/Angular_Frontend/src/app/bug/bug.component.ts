import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bug',
  templateUrl: './bug.component.html',
  styleUrls: ['./bug.component.css']
})
export class BugComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}