export class Admin{
    adminId:number;
    adminContact :string;
    adminName:string;
    adminUserid:string;
    adminPassword:string;
    role:string="admin";

}
