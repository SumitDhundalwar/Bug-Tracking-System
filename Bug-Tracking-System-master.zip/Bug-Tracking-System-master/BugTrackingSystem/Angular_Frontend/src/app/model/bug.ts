export class Bug{
  bugId:number;
  status:string;
  assignee:string;
  type:string;
  priority:string;
  startDate:string;
  endDate:string;
  bugDesc:string;
}