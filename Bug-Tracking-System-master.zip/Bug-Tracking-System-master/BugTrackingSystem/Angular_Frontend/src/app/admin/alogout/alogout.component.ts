import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alogout',
  templateUrl: './alogout.component.html',
  styleUrls: ['./alogout.component.css']
})
export class AlogoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
