export class User{
    userId:string;
    userPassword:string;
    role:string;
}
