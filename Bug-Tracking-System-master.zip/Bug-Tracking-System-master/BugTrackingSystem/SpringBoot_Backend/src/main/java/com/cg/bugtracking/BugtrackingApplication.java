package com.cg.bugtracking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BugtrackingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BugtrackingApplication.class, args);
	}

}
